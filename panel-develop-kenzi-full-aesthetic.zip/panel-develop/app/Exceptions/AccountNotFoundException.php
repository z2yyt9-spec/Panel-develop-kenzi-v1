<?php

namespace App\Exceptions;

class AccountNotFoundException extends \Exception
{
}
