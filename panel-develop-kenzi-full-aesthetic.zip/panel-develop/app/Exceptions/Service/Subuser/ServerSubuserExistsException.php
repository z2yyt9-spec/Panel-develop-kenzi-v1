<?php

namespace App\Exceptions\Service\Subuser;

use App\Exceptions\DisplayException;

class ServerSubuserExistsException extends DisplayException
{
}
