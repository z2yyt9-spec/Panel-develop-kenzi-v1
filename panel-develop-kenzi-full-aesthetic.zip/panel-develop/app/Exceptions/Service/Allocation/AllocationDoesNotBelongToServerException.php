<?php

namespace App\Exceptions\Service\Allocation;

use App\Exceptions\PterodactylException;

class AllocationDoesNotBelongToServerException extends PterodactylException
{
}
