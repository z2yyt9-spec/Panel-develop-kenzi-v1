<?php

namespace App\Exceptions\Service\Allocation;

use App\Exceptions\DisplayException;

class ServerUsingAllocationException extends DisplayException
{
}
