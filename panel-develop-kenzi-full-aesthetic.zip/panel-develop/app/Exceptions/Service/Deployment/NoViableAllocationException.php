<?php

namespace App\Exceptions\Service\Deployment;

use App\Exceptions\DisplayException;

class NoViableAllocationException extends DisplayException
{
}
