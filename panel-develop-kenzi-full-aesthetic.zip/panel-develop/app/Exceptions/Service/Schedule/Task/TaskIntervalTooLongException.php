<?php

namespace App\Exceptions\Service\Schedule\Task;

use App\Exceptions\DisplayException;

class TaskIntervalTooLongException extends DisplayException
{
}
