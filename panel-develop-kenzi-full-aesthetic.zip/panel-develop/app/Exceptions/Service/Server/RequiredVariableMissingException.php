<?php

namespace App\Exceptions\Service\Server;

use App\Exceptions\PterodactylException;

class RequiredVariableMissingException extends PterodactylException
{
}
