<?php

namespace App\Exceptions\Service\Egg\Variable;

use App\Exceptions\DisplayException;

class BadValidationRuleException extends DisplayException
{
}
