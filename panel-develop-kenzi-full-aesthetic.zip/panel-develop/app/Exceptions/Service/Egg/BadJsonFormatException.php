<?php

namespace App\Exceptions\Service\Egg;

use App\Exceptions\DisplayException;

class BadJsonFormatException extends DisplayException
{
}
