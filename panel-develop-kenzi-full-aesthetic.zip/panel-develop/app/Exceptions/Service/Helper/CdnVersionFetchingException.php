<?php

namespace App\Exceptions\Service\Helper;

class CdnVersionFetchingException extends \Exception
{
}
