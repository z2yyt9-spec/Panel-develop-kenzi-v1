<?php

namespace App\Exceptions\Repository;

use App\Exceptions\PterodactylException;

class RepositoryException extends PterodactylException
{
}
