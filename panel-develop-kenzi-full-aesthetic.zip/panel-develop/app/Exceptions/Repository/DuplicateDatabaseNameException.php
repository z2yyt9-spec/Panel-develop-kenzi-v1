<?php

namespace App\Exceptions\Repository;

use App\Exceptions\DisplayException;

class DuplicateDatabaseNameException extends DisplayException
{
}
