<?php

namespace App\Exceptions\Repository\Daemon;

use App\Exceptions\Repository\RepositoryException;

class InvalidPowerSignalException extends RepositoryException
{
}
