<?php

namespace App\Exceptions;

class AutoDeploymentException extends \Exception
{
}
