<?php

namespace App\Exceptions\Transformer;

use App\Exceptions\PterodactylException;

class InvalidTransformerLevelException extends PterodactylException
{
}
