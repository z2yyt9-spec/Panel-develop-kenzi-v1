<?php

namespace App\Exceptions;

class PterodactylException extends \Exception
{
}
