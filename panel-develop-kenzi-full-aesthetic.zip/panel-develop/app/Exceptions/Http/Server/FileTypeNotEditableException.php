<?php

namespace App\Exceptions\Http\Server;

use App\Exceptions\DisplayException;

class FileTypeNotEditableException extends DisplayException
{
}
