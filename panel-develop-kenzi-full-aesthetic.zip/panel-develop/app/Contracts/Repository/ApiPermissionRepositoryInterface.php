<?php

namespace App\Contracts\Repository;

interface ApiPermissionRepositoryInterface extends RepositoryInterface
{
}
