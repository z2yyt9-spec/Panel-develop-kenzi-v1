<?php

namespace App\Contracts\Repository;

interface ServerVariableRepositoryInterface extends RepositoryInterface
{
}
