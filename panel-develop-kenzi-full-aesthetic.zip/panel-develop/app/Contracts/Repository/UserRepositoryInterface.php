<?php

namespace App\Contracts\Repository;

interface UserRepositoryInterface extends RepositoryInterface
{
}
