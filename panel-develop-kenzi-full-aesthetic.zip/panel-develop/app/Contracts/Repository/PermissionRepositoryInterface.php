<?php

namespace App\Contracts\Repository;

interface PermissionRepositoryInterface extends RepositoryInterface
{
}
